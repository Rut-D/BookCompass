/* ---------------- nav scroll state ---------------- */
const header = document.getElementById('siteHeader');
window.addEventListener('scroll', () => {
  header.classList.toggle('scrolled', window.scrollY > 30);
});

/* ---------------- scroll reveal ---------------- */
const revealEls = document.querySelectorAll('.reveal');
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
}, { threshold: 0.15 });
revealEls.forEach(el => io.observe(el));

/* ---------------- book dataset ---------------- */
const beanFilled = '<svg viewBox="0 0 40 60" class="filled" fill="currentColor"><ellipse cx="20" cy="30" rx="17" ry="27"/><path d="M20 5v50" stroke="var(--cream-warm)" stroke-width="3"/></svg>';
const beanEmpty  = '<svg viewBox="0 0 40 60" class="empty" fill="currentColor"><ellipse cx="20" cy="30" rx="17" ry="27"/><path d="M20 5v50" stroke="var(--cream)" stroke-width="3"/></svg>';


function beanRating(n){
  let out = '';
  for(let i=1;i<=5;i++) out += (i<=n ? beanFilled : beanEmpty);
  return out;
}


function displayBooks(books){

    const grid = document.getElementById("resultsGrid");
    grid.innerHTML = "";

    if(books.length === 0){

        grid.innerHTML = `
            <div class="no-results">
                <h2>📚 No books found</h2>
                <p>Try searching for:</p>

                <div class="suggestions">
                    <span onclick="quickSearch('Mystery')">Mystery</span>
                    <span onclick="quickSearch('Fantasy')">Fantasy</span>
                    <span onclick="quickSearch('Romance')">Romance</span>
                    <span onclick="quickSearch('Thriller')">Thriller</span>
                </div>
            </div>
        `;

        return;
    }

    books.forEach((book,i)=>{

        let genres = [];

        if(book.genres){

            genres = book.genres
                .replace("[","")
                .replace("]","")
                .replaceAll("'","")
                .split(",")
                .map(g=>g.trim())
                .slice(0,3);

        }

        const card = document.createElement("div");

        card.className = "lib-card";
        card.style.animationDelay = `${i*0.08}s`;

        card.innerHTML = `

            <img src="${book.coverImg}" class="book-cover">

            <div class="lib-top">
                <span class="call-number">⭐ ${book.rating}</span>
                <span class="stamp">Recommended</span>
        </div>

        <div class="recommendation-label">
            <span>Based on your search</span>
        </div>

            <h3>${book.title}</h3>

            <div class="lib-author">
                ${book.author}
            </div>

            <div class="lib-tags">
                ${
                    genres.map(g=>`<span class="tag-pill">${g}</span>`).join("")
                }
            </div>

            <div class="why-book">

                <h4>✨ Why this book?</h4>

                <p>📚 <strong>Genres:</strong> ${genres.join(" • ")}</p>

                <p>⭐ <strong>Rating:</strong> ${book.rating}/5</p>

                <p>🔎 Recommended because it closely matches your search for
                <strong>"${book.query}"</strong>.</p>

            </div>

            <p class="lib-blurb">
                ${
                    book.description
                    ? book.description.substring(0,250)+"..."
                    : "No description available."
                }
            </p>

            <button class="read-btn">
                Read More
            </button>

        `;

        card.onclick = ()=>openBook(book);

        grid.appendChild(card);

    });

}

function openBook(book){

    document.getElementById("bookModal").style.display = "block";

    document.getElementById("modalImg").src = book.coverImg;
    document.getElementById("modalTitle").innerText = book.title;
    document.getElementById("modalAuthor").innerText = book.author;
    document.getElementById("modalGenres").innerText = book.genres;
    document.getElementById("modalDesc").innerText = book.description;
}

async function findMyBook() {

    const query = document.getElementById("bookInput").value.trim();

    if (!query) return;

    const btn = document.getElementById("findBtn");

    btn.disabled = true;
    btn.innerHTML = "🔍 Searching...";

    console.log("BUTTON CLICKED");
    console.log("Query:", query);

    try {

        const response = await fetch("http://127.0.0.1:5000/recommend", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ query })
        });

        console.log("Response:", response);

        const books = await response.json();

        window.books = books;
        console.log(books);

        displayBooks(books);
          document.getElementById('results').scrollIntoView({behavior:'smooth', block:'start'});


    } catch (err) {

        console.error(err);
        alert("Something went wrong!");

    } finally {

        btn.disabled = false;
        btn.innerHTML = "Find My Book";

    }
}

document.getElementById('findBtn').addEventListener('click', findMyBook);
document.getElementById('bookInput').addEventListener('keydown', (e)=>{
  if(e.key === 'Enter' && (e.metaKey || e.ctrlKey)) findMyBook();
});

document.querySelectorAll('.chip').forEach(chip => {
  chip.addEventListener('click', () => {
    document.getElementById('bookInput').value = chip.textContent;
    findMyBook();
  });
});
document.querySelector(".close").onclick = () => {
    document.getElementById("bookModal").style.display = "none";
};

function quickSearch(query){

    document.getElementById("bookInput").value = query;

    findMyBook();

}